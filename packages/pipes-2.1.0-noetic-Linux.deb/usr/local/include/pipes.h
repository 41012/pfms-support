#ifndef PIPES_H
#define PIPES_H
#include <string>
#include <vector>

#include <atomic>
#include <mutex>
#include <condition_variable>
#include <thread>

#include "pfms_types.h"

////////////////////////////////
#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/Range.h"
#include "visualization_msgs/MarkerArray.h"

#include <sstream>
// thread and chrono are for time and sleeping respectively
#include <chrono>
#include <thread>
#include <string>
#include "tf/transform_datatypes.h"

using std::string;

struct sync_details{
    std::condition_variable cv; //<! convar to synch getting and reading data
    std::atomic<bool> ready;    //<! Indicates if new  data has been recieved
    std::mutex mtx;             //<! mutex to protect data
};

class Pipes
{
public:


    /*! @brief Default constructor
     *
     *  Will establish the communication to ROS
     *  Should ONLY be created to establish communication and reused
     */
    Pipes();

    ~Pipes();

    /*! @brief Writes UGV command to the pipe, blocking call, will
     * be suspended until the pipe is available
     *
     *  @param ugv - the command to be written
     */
    void writeCommand(pfms::commands::UGV ugv);

    /*! @brief Writes UAV command to the pipe, blocking call, will
     * be suspended until the pipe is available
     *
     *  @param uav - the command to be written
     */
    void writeCommand(pfms::commands::UAV uav);


    /*! @brief Writes Goal to the pipe, blocking call, will
     * be suspended until the pipe is available
     *
     *  @param goal - the goal to be written to pipe
     */
    void writeCommand(pfms::geometry_msgs::Goal goal);

    /*! @brief Reads LaserScan from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param laserScan - the LaserScan from the pipe (read/write)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::sensor_msgs::LaserScan & laserScan);

    /*! @brief Reads Sonar from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param scan - the Sonar reading from the pipe (read/write)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::sensor_msgs::Sonar & scan);


    /*! @brief Reads Odometry from the pipe, blocking call, will
     * be suspended until commend written or timeout (5s)
     *
     *  @param odo - the Odometry from the pipe (read)
     *  @return true indicates is command written sucsesfully,
     * false timeout occured (pipe might not be open)
     */
    bool readCommand(pfms::nav_msgs::Odometry& odo);

    /*! @brief Thread safe obtaining odometry @sa readOdo
     *
     *  @return the Odometry already obtained and stored.
     */
    pfms::nav_msgs::Odometry getOdo();

private:
    void ugvOdoCallback(const nav_msgs::Odometry::ConstPtr& msg);
    void uavOdoCallback(const nav_msgs::Odometry::ConstPtr& msg);
    void laserCallback(const sensor_msgs::LaserScan::ConstPtr& msg);
    void sonarCallback(const sensor_msgs::Range::ConstPtr& msg);
    void spin(void);
    void addMarker(double x, double y, unsigned int seq);
    void uavLand(void);

private:

    pfms::nav_msgs::Odometry ugvOdo_; //<! Local record of odometry;
    pfms::nav_msgs::Odometry uavOdo_; //<! Local record of odometry;
    pfms::sensor_msgs::Sonar sonar_;
    pfms::sensor_msgs::LaserScan laser_;
    std::vector<std::thread> threads_; // We add threads onto a vector here to be able to terminate then in destructor
    std::atomic<bool> running_; // We use this to indicate threads shoudl still be running

    ros::Subscriber ugvOdoSub_,uavOdoSub_;
    ros::Subscriber laserSub_;
    ros::Subscriber sonarSub_;

    sync_details ugvOdoSync_;
    sync_details uavOdoSync_;
    sync_details sonarSync_;
    sync_details laserSync_;

    ros::Publisher vizPub_;
    ros::Publisher uavCmdPub_,uavTakeOffPub_, uavLandPub_ ;
    ros::Publisher throttlePub_, brakePub_, steeringPub_;

    int marker_counter_;
    unsigned int seq_;
    visualization_msgs::MarkerArray marker_array_;    

    bool uavFlying_;
    unsigned int ugvSeq_;
    double ugvSteering_;

};

#endif // PIPES_H
