#ifndef LINKCOMMAND_H
#define LINKCOMMAND_H

#include "pfms_types.h"
#include <vector>
#include <string>

class LinkCommand
{
public:
    LinkCommand();
    LinkCommand(bool debug);

    std::string mapServiceToPlatform(pfms::PlatformType platform){
        std::string service;
        switch(platform) {
          case pfms::PlatformType::ACKERMAN:
            service = "ugv_reach";
            break;
          case pfms::PlatformType::QUADCOPTER:
            service = "uav_reach";
            break;
        }
        return service;
    }

    /*! @brief Sends the odometry that get's actioned via a service call to gazebo (the simulator). The change is instateneous
     *
     *  @param odo - The odometry, currently yaw is the only orientation used, the velocity is singnored (and set to zero)
     */
    bool writeCommand(pfms::nav_msgs::Odometry odo);

    /*! @brief Sends the goal that needs to be checked via a service call to gazebo_tf odo checker
     *
     *  @param goal - The point that needs to be reached
     *  @param platform - platform to check
     *  @note Has hardcoded values of ROS services coresonding to the platform name
     */
    bool writeCommand(pfms::geometry_msgs::Point goal,pfms::PlatformType platform);

    /*! @brief Send the goals that needs to be checked via a service call to gazebo_tf odo checker
     *
     *  @param goals - The points that needs to be reached
     *  @param service - Service name for ros to check
     */
    bool writeCommand(std::vector<pfms::geometry_msgs::Point> goals,std::string service);


    /*! @brief Check that goals set via @sa writeCommand has been travelled through,
     * checks this via a service call to gazebo_tf odo checker
     *
     *  @param service - Service name for ros to check
     *  @param [in|out] - closest distance to a point supplied
     *  @return goals were travelled through.
     */
    bool checkGoalsReached(std::string service, double &distance);

    /*! @brief Check that goals set via @sa writeCommand has been travelled through,
     * checks this via a service call to gazebo_tf odo checker
     *
     *  @param service - Service name for ros to check
     *  @return goals were travelled through.
     */
    bool checkGoalsReached(std::string service){
        double d=0;
        return checkGoalsReached(service, d);
    }

    /*! @brief Check that goal set via @sa writeCommand has been travelled through,
     * checks this via a service call to gazebo_tf reach
     *
     *  @param platform - platform to check
     *  @return distance to the goal
     */
    double checkGoalDistance(pfms::PlatformType platform){
        std::string service = mapServiceToPlatform(platform);
        double d;
        checkGoalsReached(service, d);
        return d;
    }

    /*! @brief Check the pose of the frame
     * checks this via a service call to gazebo
     *
     *  @param frame - frame name for ros to check with reference to world frame
     *  @return odometry - the pose of the frame with reference to world frame
     */
    pfms::nav_msgs::Odometry checkTransform(std::string frame);


private:
    bool debug_;/*!< bool indicating if debug information to be provided */

};

#endif // LINKCOMMAND_H
