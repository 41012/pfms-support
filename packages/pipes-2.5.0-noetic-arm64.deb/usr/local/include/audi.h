#ifndef AUDI_H
#define AUDI_H

#include "pfms_types.h"

class Audi
{
public:
  //Default constructor should set all sensor attributes to a default value
  Audi();
  ~Audi();

  bool checkOriginToDestination(pfms::nav_msgs::Odometry origin, pfms::geometry_msgs::Point goal,
                                 double& distance, double& time, pfms::nav_msgs::Odometry& estimatedGoalPose);

  bool computeSteering(pfms::nav_msgs::Odometry origin, pfms::geometry_msgs::Point goal,
                      double& steering,double& dist);

private:
  pfms::PlatformType type_;
  const double steering_ratio_;
  const double lock_to_lock_revs_;
  const double max_steer_angle_;
  const double wheelbase_;
  const double max_break_torque_;
  const double steadyStateV_;
  const double deltaD_;
  double prevD_;

};

#endif // Audi_H
